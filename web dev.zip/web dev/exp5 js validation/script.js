function validateSignup() {
    let name = document.getElementsByName("name")[0].value;
    let email = document.getElementsByName("email")[0].value;
    let pass = document.getElementById("password").value;
    let confirm = document.getElementById("confirm").value;

    if (name === "" || email === "" || pass === "") {
        alert("All fields are required");
        return false;
    }

    let emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    if (!email.match(emailPattern)) {
        alert("Invalid email");
        return false;
    }

    if (pass.length < 6) {
        alert("Password must be at least 6 characters");
        return false;
    }

    if (pass !== confirm) {
        alert("Passwords do not match");
        return false;
    }

    return true;
}

function validateLogin() {
    let user = document.getElementsByName("user")[0].value;
    let pass = document.getElementsByName("password")[0].value;

    if (user === "" || pass === "") {
        alert("All fields required");
        return false;
    }

    return true;
}