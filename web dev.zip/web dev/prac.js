function validateForm() {
    let name = document.getElementsByName("name")[0].value;
    let email = document.getElementsByName("email")[0].value;
    let mobile = document.getElementsByName("mobile")[0].value;
    let course = document.getElementsByName("coure")[0].value;

    if (name === "" || email === "" || username === "" ){
        aleart("All feilds are required");
    return false;
    }

    let emailPattern = /@/;
    if (!email.match(emailPattern)){
        alert("invalid email");
        return false;
    }

    if (mobile.length !=10 || isNan(mobile)){
        alert=("invalid mobile no");
        return false;
    }

    return true;

}

