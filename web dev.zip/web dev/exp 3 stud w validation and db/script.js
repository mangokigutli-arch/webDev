function validateForm() {

    let name = document.getElementsByName("name")[0].value;
    let email = document.getElementsByName("email")[0].value;
    let mobile = document.getElementsByName("mobile")[0].value;
    let course = document.getElementsByName("course")[0].value;

    if (name === "" || email === "" || mobile === "" || course === "") {
        alert("All fields are required");
        return false;
    }

    let emailPattern = /@/;
    if (!email.match(emailPattern)) {
        alert("Invalid email");
        return false;
    }

    if (mobile.length != 10 || isNaN(mobile)) {
        alert("Invalid mobile number");
        return false;
    }

    return true;
}