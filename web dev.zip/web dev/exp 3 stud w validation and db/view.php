<?php
include "db.php";

$result = mysqli_query($conn, "SELECT * FROM students");

echo "<h2>Student Records</h2>";
echo "<table border='1' cellpadding='10'>";
echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Mobile</th><th>Course</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>".$row['id']."</td>";
    echo "<td>".$row['name']."</td>";
    echo "<td>".$row['email']."</td>";
    echo "<td>".$row['mobile']."</td>";
    echo "<td>".$row['course']."</td>";
    echo "</tr>";
}

echo "</table>";
?>