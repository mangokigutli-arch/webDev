<?php
$conn = mysqli_connect("localhost", "root", "", "dbName");

if (!$conn) {
    die("Connection failed");
}
?>