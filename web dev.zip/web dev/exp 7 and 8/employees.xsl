<?xml version="1.0"?>

<xsl:stylesheet version="1.0"
xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

<xsl:template match="/">

<html>
<body>

<h2>Employee Salary Report</h2>

<table border="1" cellpadding="8">
<tr style="background-color:lightgray;">
    <th>ID</th>
    <th>Name</th>
    <th>Department</th>
    <th>Salary/Day</th>
    <th>Working Days</th>
    <th>Total Salary</th>
</tr>

<xsl:for-each select="employees/employee">

   
    <xsl:if test="salaryPerDay * workingDays &gt; 10000">

<tr>
    <td><xsl:value-of select="@id"/></td>
    <td><xsl:value-of select="name"/></td>
    <td><xsl:value-of select="department"/></td>
    <td><xsl:value-of select="salaryPerDay"/></td>
    <td><xsl:value-of select="workingDays"/></td>

    <td>
        <xsl:value-of select="salaryPerDay * workingDays"/>
    </td>
</tr>

    </xsl:if>

</xsl:for-each>

</table>

</body>
</html>

</xsl:template>

</xsl:stylesheet>